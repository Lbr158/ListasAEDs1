/*Três amigos jogaram na loteria. Caso eles ganhem, o prêmio deve ser repartido
proporcionalmente ao valor que cada um deu para a realização da aposta. Faça um
programa que leia quanto cada apostador investiu, o valor do prêmio, e imprima quanto
cada um ganharia do prêmio com base no valor investido.
*/
#include<stdio.h>
int main (void){

int investimento1,investimento2,investimento3,premio;

printf("entre com o investimento do primeiro participante\n");
scanf("%d",&investimento1);
printf("entre com o investimento do segundo participante\n");
scanf("%d",&investimento2);
printf("entre com o investimento do terceiro participante\n");
scanf("%d",&investimento3);
printf("entre com o valor do premio");
scanf("%d",&premio);

float somai = investimento1 + investimento2 + investimento3;
float inv1 = investimento1 /  somai;
float inv2 = investimento2 /  somai;
float inv3 = investimento3 /  somai;

float final1 = premio*inv1;
float final2 = premio*inv2;
float final3 = premio*inv3;

printf("Valor do primeiro ivestidor : %1.f \n",final1);
printf("Valor do segundo ivestidor : %1.f \n",final2);
printf("Valor do terceiro ivestidor : %1.f \n",final3);
return (0);
}