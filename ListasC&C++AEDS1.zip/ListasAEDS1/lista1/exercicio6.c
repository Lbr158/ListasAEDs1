/*Leia um valor inteiro em segundos e imprima o equivalente em horas, minutos e
segundos
*/
#include<stdio.h>

int main(void){
int sec,resto,hora,min,sec2;

printf("entre com o valor inteiro em segundos");
scanf("%d",&sec);

hora = sec / 3600;
resto = sec % 3600;
min = resto / 60;
sec2 = resto % 60;

printf("%d:%d:%d", hora, min, sec2);
return (0);

}
