/*Considere que os valores (inteiros e positivos) para as variáveis a, b e c
correspondem aos lados de um triângulo retângulo com catetos a e b, e hipotenusa c.
*/

#include<stdio.h>
#include<math.h>

int main (void){
int a,b,c;

float s = (a + b + c) /2 ;
float area = sqrt(s*(s-a)*(s-b)*(s-c));

return (0);
}