/*a usa a função pow da biblioteca math.h para calcular e imprimir quantos valores
um binário de 4 bits comporta. Nota: pow(x,y) calcula x
y

*/


#include <stdio.h>
#include <math.h>
 
int main()
{
  int com = pow(2, 4);
  printf("\nUm binário de 4 bits com até %i valores.\n", com);
  printf("\nDigite um número binário de 4 dígitos.\n");

/*
b Recebe do usuário 4 valores referentes aos bits de um binário e imprime o decimal
equivalente. Nota: para facilitar, os valores podem ser lidos com “%d” como se cada
bit fosse um inteiro.
*/

  int v1, v2, v3, v4;

  printf("Dígito 1: ");
  scanf("%i", &v1);
  printf("Dígito 2: ");
  scanf("%i", &v2);
  printf("Dígito 3: ");
  scanf("%i", &v3);
  printf("Dígito 4: ");
  scanf("%i", &v4);

  int r = (v1 * pow(2, 3)) + (v2 * pow(2, 2)) + (v3 * pow(2, 1)) + (v4 * pow(2, 0));

  printf("\nDecimal: %i", r);
  return 0;
}