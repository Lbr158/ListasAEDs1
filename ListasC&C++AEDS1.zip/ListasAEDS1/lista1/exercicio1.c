/*1 Escreva um código para calcular o seno de um valor em graus. O valor deve ser
lido do usuário com a função scanf e seu seno deve ser impresso usando a função
printf. Compile o código, verificando se algum erro ocorreu. Execute o código com
diversos valores de ângulos e verifique se o resultado apresentado está correto.
*/

#include<stdio.h>
#include <math.h>
int main (void){

int  valg;
float seno,radiano,pi;

scanf("%d", &valg );
pi = 3.14;
radiano = ( valg * pi ) / 180 ;
seno = sin(radiano);
printf("seu seno =  %.2f ",seno);
return (0);
}