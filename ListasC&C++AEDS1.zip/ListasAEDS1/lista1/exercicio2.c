/*2 Uma conta poupança foi aberta com um depósito de R$500,00. Esta conta é
remunerada em 1% de juros ao mês. O código a seguir apresenta uma forma de
implementação para três meses de acúmulo de juros. Reescreva esse código usando
apenas duas variáveis
*/

#include <stdio.h>
#include <math.h>

int main (void) {
float saldo=500.0;
float juros = 1.01;
saldo = (saldo * juros);
saldo = (saldo *juros);
saldo = (saldo *juros);
  
printf("No quarto mês eu tenho %.2f reais na poupanca/n", saldo);
return (0);
}