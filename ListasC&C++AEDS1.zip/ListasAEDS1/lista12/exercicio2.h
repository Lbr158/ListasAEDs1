/*Esse exercício é feito com base no módulo Empresa, implementado nos arquivos empresa.h e empresa.cpp que acompanham esse exercício.
 A classe Empresa é capaz de armazenar dados de genéricos de uma empresa (Nome, Endereço, Cidade, Estado, CEP e Telefone).
  Ele inclui um construtor, um conjunto de getters and setters, além de uma função print que imprime seus atributos.

Utilize a classe Empresa como base para criar a sua empresa (ex.: Restaurante, Lan House, Bar, etc.). Essa classe deve:
- ser implementada na estrutura de módulos (Classe.h e Classe.cpp)
- deve herdar a classe Empresa e
- definir pelo menos um atributo específico da sua empresa escolhida (ex.: preço médio dos pratos).
Crie um construtor, as funções get e set apenas dos atributos específicos da subclasse, e uma função print que imprime todos os atributos (inclusive da classe mãe). Crie também um arquivo main.cpp para testar a criação de um objeto de sua subclasse e chamar as funções implementadas.
*/
#include <iostream>
#include <string>

using namespace std;

class barbearia{
    private:
        string nome;
        string endereco;
        int numero_de_pentes;
        int numero_de_barbeadores;
    public:
        barbearia(struing nome,string endereco,int numero_de_pentes,int numero_de_barbeadores);
        string getnome();
        string getendereco();
        int getnumero_de_pentes();
        int getnumero_de_barbeadores();
        void setnome(string nome);
        void setendereco(string endereco);
        void setnumero_de_pentes(int numero_de_pentes);
        void setnumero_de_barbeadores(int numero_de_barbeadores);
        void print();
}