/*Esse exercício é feito com base no módulo Empresa, implementado nos arquivos empresa.h e empresa.cpp que acompanham esse exercício.
 A classe Empresa é capaz de armazenar dados de genéricos de uma empresa (Nome, Endereço, Cidade, Estado, CEP e Telefone).
  Ele inclui um construtor, um conjunto de getters and setters, além de uma função print que imprime seus atributos.

Utilize a classe Empresa como base para criar a sua empresa (ex.: Restaurante, Lan House, Bar, etc.). Essa classe deve:
- ser implementada na estrutura de módulos (Classe.h e Classe.cpp)
- deve herdar a classe Empresa e
- definir pelo menos um atributo específico da sua empresa escolhida (ex.: preço médio dos pratos).
Crie um construtor, as funções get e set apenas dos atributos específicos da subclasse, e uma função print que imprime todos os atributos (inclusive da classe mãe). Crie também um arquivo main.cpp para testar a criação de um objeto de sua subclasse e chamar as funções implementadas.
*/
#include "exercicio2.h"
barbearia :: barbearia (){
    nome = "";
    endereco = "";
    numero_de_pentes = "";
    numero_de_barbeadores = "";
}

barbearia::barbearia(string nome,string endereco,int numero_de_pentes,int numero_de_barbeadores)
{
    this -> nome = nome;
    this -> endereco = endereco;
    this -> numero_de_pentes = numero_de_pentes;
    this -> numero_de_barbeadores = numero_de_barbeadores;
}
string barbearia::getNome()
{
    return nome;
}
string barbearia::getEndereco()
{
    return endereco;
}
int barbearia::numero_de_pentes()
{
    return numero_de_pentes;
}
int barbearia::numero_de_barbeadores()
{
    return numero_de_barbeadores;
}
void barbearia :: setNome(string nome)
{
    this -> nome = nome;
}
void barbearia :: setendereco(string endereco)
{
    this -> endereco = endereco;
}
void barbearia :: setnumero_de_pentes(int numero_de_pentes)
{
    this -> numero_de_pentes = numero_de_pentes;
}
void barbearia :: setnumero_de_barbeadores(int numero_de_barbeadores)
{
    this -> numero_de_barbeadores = numero_de_barbeadores;
}
void barbearia :: print (){
    cout << "Nome: " << nome << endl;
    cout << "Endereco: " << endereco << endl;
    cout << "numero de pentes: " << numero_de_pentes << endl;
    cout << "numero de barbeadores: " << numero_de_barbeadores << endl;
 }