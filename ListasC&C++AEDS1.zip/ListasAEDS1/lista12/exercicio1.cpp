/*Implemente uma televisão. A televisão tem um controle de volume do som e um controle de seleção de canal.

- O controle de volume permite aumentar ou diminuir a potência do volume de som em uma unidade de cada vez, ou colocar a TV no mudo.
- O controle de canal também permite aumentar e diminuir o número do canal em uma unidade, porém, também possibilita trocar para um canal indicado (entre 0 e 99).
- Também devem existir métodos para consultar o valor do volume de som e o canal selecionado.

No programa principal, crie uma televisão inicializada no canal 10 e volume 0, e um laço infinito com um menu com as opções de (1) alterar volume, (2) alterar canal ou (3) imprimir informações. A opção volume pede um dado adicional (+, - ou M para mudo) referente à ação desejada, já opção canal pode receber + ou - referente a mudanças de uma unidade, ou um valor numérico referente ao canal desejado.
*/
#include <iostream>
using namespace std;
class televisão
{
protected:
int volumetv;
int canaltv;
};
class controle : public televisão
{
  int getvolume();
  int getcanal();
  void setvolume();
  void setcanal();
}
void setcanal (int canalexpecifico){
    televisão t;
    if (canalexpecifico >= 0 || canalexpecifico <= 99){
        this -> t.canaltv = canalexpecifico;
    }
    else cout >> "canal invalido";
}

void qualcanal_e_volume{
    televisão t;
    cout >> "o canal atual é " << t.canaltv << "e o volume é" << t.volumetv <<;
}
