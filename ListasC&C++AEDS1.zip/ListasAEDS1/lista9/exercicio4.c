/*Escreva um programa que possua a estrutura carro, com dois atributos: uma string modelo
(Fusca, Gol, etc.) e consumo, sendo o consumo referente a quantos km esse carro faz por
litro. Leia do usu ́ario os modelos e os seus respectivos consumos e imprima qual dos carros
é o mais econˆomico. Seu programa deve alocar dinamicamente o espa ̧co
necessário para a estrutura.
*/

#include<stdio.h>
#include<stdlib.h>
typedef struct carro_
{
    char *modelo[10];
    int *consumo;
}carro;

int main(void){
    struct carro_ c;
    int aux,n,i;
    char aux2;
    printf("entre com o numero de carros");
    scanf("%d",&n);
    c.modelo = (*char) malloc (n * sizeof(char*));
    c.consumo = (*int) malloc (n * sizeof(int*));
    for ( i = 0; i < n; i++)
    {
        printf("entre com o modelo");
        scanf("%s",c.modelo[i]);
        printf("entre com o modelo");
        scanf("%d",c.consumo[i]);
        if (aux < c.consumo[i];)
        {
            aux = c.consumo[i];
            aux2 = c.modelo[i];
        }
        
    }
    printf("%s",aux2);
return(0);     
}
