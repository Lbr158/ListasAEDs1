/*Numa partitura, as notas são representadas por símbolos diferentes que indicam a sua
duração. Uma música é dividida em uma sequência de compassos, e cada compasso possui
um conjunto de notas. Como Pedro é um iniciante, seu professor de música lhe ensinou que
a duração das notas de um compasso deve sempre somar 1. No nosso software, cada nota
vai ser representada por um caracter, de acordo com a tabela a seguir:
*/
#include<stdio.h>
#include<stdlib.h>

typedef struct nota_{
    char id;
    float dur;
}nota;

float getduracao (int notas,int id){
    for (int i = 0; i < 7; i++)
    {
        if(notas[i].id == id)
        return notas[i].dur;
    }
    
}

int main(void){
    nota notas[7];
    notas[0].id = "W";
    notas[0].dur = 1;
     notas[1].id = "H";
    notas[1].dur = 1/2;
     notas[2].id = "Q";
    notas[2].dur = 1/4;
     notas[3].id = "E";
    notas[3].dur = 1/8;
     notas[4].id = "S";
    notas[4].dur = 1/16;
     notas[5].id = "T";
    notas[5].dur = 1/32;
     notas[6].id = "X";
    notas[6].dur = 1/64;

    char ids[] = "WHQESTX";
    int d = 1;
    for (int i = 0; i < 7; i++)
    {
        notas[i].id = ids[i];
        notas[i].dur = d;
        d /= 2;
    }
    int qtd = 0;
    int soma = 0;
    char entrada[100];
    gets(entrada);
    for ( i = 1; i < strlen(entrada); i++)
    {
        float d = getdur(entrada[i]);
        soma+= d;
        if(entrada[i]== '/'){
            if(soma ==1)qtd++;
            soma=0;
        }
    }
    
}
