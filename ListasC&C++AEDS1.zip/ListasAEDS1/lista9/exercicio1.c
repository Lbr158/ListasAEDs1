/*Faça um programa que controla o consumo de energia dos eletrodomésticos de uma
casa. Para isso crie a estrutura eletrodoméstico com os seguintes atributos:
○ Nome: char[30]
○ Potência em kW: float
○ Tempo ativo por dia (em horas): float
Leia do usuário os N eletrodomésticos da sua casa (pode perguntar o valor de N no
início da execução) e calcule o consumo total da casa por mês, e o consumo relativo
de cada eletrodoméstico também por mês (consumo/consumo_total). Apresente
esse último dado em porcentagem.
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct eletrodomestico
{
    char nome [30];
    float potencia;
    float t_ativo;
    float consumopormaquina[100];
}eletro;
int main (void){
    struct eletrodomestico e[100];
    int i,horas = 0,n,consumott= 0,consumomes;
    printf("entre com o numero de eletrodomesticos\n");
    scanf("%d",&n);
    for (i=0;i<n;i++){
        printf("entre com o nome\n");
        scanf("%s", e[i].nome);
        printf("entre com a potencia\n");
        scanf("%f", &e[i].potencia);
        printf("entre com o tempo ativo em hooras\n");
        scanf("%f", &e[i].t_ativo);
        consumott += e->potencia;
        horas += e->t_ativo;
        e->consumopormaquina[i] = e->potencia * e->t_ativo;
    }
     consumomes = e->potencia*e->t_ativo*30;
     printf("consumo mensal : %dkw\n",consumomes);
     for ( i = 1; i < n; i++)
     {
         printf("o consumo da %d maquina e: %1.f\n",i,e[i].consumopormaquina[i]);
     }
     
}