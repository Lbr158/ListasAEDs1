/*Vamos criar uma agenda de compromissos! Para isso serão necessárias os seguintes tipos
de dados:
○ Data: composto por dia, mês, ano
○ Hora: composto por horas, minutos, segundos
○ Compromisso: composto por data, hora e descrição.
Faça um menu para o usuário com as seguintes opções:
1. Registrar compromisso
2. Listar todos os compromissos
3. Listar compromissos de um mês
A funcionalidade listar por mês, deve solicitar ao usuário o mês (de 01 a 12) e listar os
compromissos daquele mês (do ano corrente).
*/
#include<stdio.h>
#include<stdlib.h>
struct dados_
{
    data [] [] [];
    hora [] [] [];
    compromisso [] [] [];
}dados;
void registrar (int data [] [] [],int hora [] [] [], int compromisso [] [] []){
    
}
void listames 
int main(void){
    int escolha;
    printf("digite o numero correspondete a sua escolha\n1. registrar\n2.listar todos os compromussos\n3.listar compromissos de um mês");
    scanf("%d",&escolha);
    if (escolha == 1)
    {
        registrar();
    }
    if (escolha == 2)
    {
        listatudo;
    }
    if (escolha == 3)
    {
        listames;
    }
    

}