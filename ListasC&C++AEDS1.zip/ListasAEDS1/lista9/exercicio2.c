/*Seu programa irá precisar de um tipo de dado enum com os dias da semana. Crie
também uma matriz de char onde cada linha é o nome de um dia da semana. Ambas as
estruturas devem ser correspondentes, ou seja, o valor de uma constante do enum deve
se referir à linha da matriz que contém o nome daquele dia da semana.
O usuário vai fornecer o nome de um dia da semana, seu programa deve:
○ converter o nome para um inteiro (a linha da matriz)
○ realizar um switch-case para imprimir se aquele é um dia da semana ou um
fim de semana.
*/
#include<stdio.h>
#include<stdlib.h>
int main(void){
    enum  semana{segunda = 1,terca = 2,quarta = 3,quinta = 4,sexta = 5,sabado = 6,domingo = 7};
    char matriz [7];
    matriz [1] = 1;
    matriz [2] = 2;
    matriz [3] = 3;
    matriz [4] = 4;
    matriz [5] = 5;
    matriz [6] = 6;
    matriz [7] = 7;

    char nome [8];
    int nome2;
    printf("entre conm o nome\n");
    scanf("%s",&nome);
    
    if (nome == segunda)
    {
        nome2 = matriz [1];
    }
    if (nome == terca)
    {
        nome2 = matriz [2];
    }
    if (nome == quarta)
    {
        nome2 = matriz [3];
    }
    if (nome == quinta)
    {
        nome2 = matriz [4];
    }
    if (nome == sexta)
    {
        nome2 = matriz [5];
    }
    if (nome == sabado)
    {
        nome2 = matriz [6];
    }
    if (nome == domingo)
    {
        nome2 = matriz [7];
    }
    switch (nome2)
    {
    case 1:
        printf("dia da semana");
        break;
    case 2:
         printf("dia da semana");
        break;
    case 3:
         printf("dia da semana");
        break;
    case 4: 
         printf("dia da semana");
        break;
    case 5:
         printf("dia da semana");
        break;
    case 6:
         printf("final de semana");
        break;   
    default:
         printf("final de semana");
        break;     
    }
    return (0);
}
