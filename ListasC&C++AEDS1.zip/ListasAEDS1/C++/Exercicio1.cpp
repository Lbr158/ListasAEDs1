//  Codigo onde o usuario entra com sua data de nascimento e se ja fez aniversario, e o codigo volta se o usuario é maior de idade e pode tirar carteira.
#include <iostream>
using namespace std;
int main(){

    //Criando as variaveis int e char

    int idade,anoN;
    char niv;

    //salvando as variaveis

    cout << "entre com seu ano de nascimento\n";
    cin >> anoN;
    cout << "ja fez aniversario ?\n";
    cin >> niv;

    //Ajustando a idade e verificando se a pessoa é maior de 18 e imprimindo "vc e maior de idade e pode conseguir carteira de habilitacao" se o caso for verdadeiro

    idade = 2022 - anoN;
    if (niv == 'N')
    {
        idade--;
    }
    if (idade >= 18)
    {
        cout << "vc e maior de idade e pode conseguir carteira de habilitacao";
        
    }
    
}