#include <iostream>
using namespace std;
class pessoa{
    public:
  int codigo,nome,idade,endereço,numero,complemento;
};
int main (void){
    pessoa p[10];
    for (int i = 0; i < 10; i++)
    {
        cout >> "entre com o codigo,nome,idade,endereço,numero e complemento"
        cin << p.codigo[i],p.nome[i],p.idade[i],p.endereço[i],p.numero[i],p.complemento[i];
    }
    
}