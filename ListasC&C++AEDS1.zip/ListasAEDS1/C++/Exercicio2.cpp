#include <iostream>
using namespace std;
int main (){
    int cont0 = 0,contp = 0,contn = 0,n1,n2,n3,n4,n5;
    cout << "entre com os numeros separados por espaço";
    cin >> n1,n2,n3,n4,n5;
    if (n1 > 0 && n2 > 0 && n3 > 0 && n4 > 0 && n5 > 0)
    {
        contp++;
    }
    if (n1 < 0 && n2 < 0 && n3 < 0 && n4 < 0 && n5 < 0)
    {
        contn++;
    }
    else cont0++;
}