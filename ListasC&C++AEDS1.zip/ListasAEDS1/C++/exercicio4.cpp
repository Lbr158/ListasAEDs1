#include <iostream>
using namespace std;
void maior (int a,int b){
    int c,d;
    c = a;
    d = b
    if (a > b)
    {
         cout << a,b;
    }
    else{
      a = d;
      b = c;
      cout << a,b;
    } 
}
int main (){
 int n1,n2;
  cout << "entre com os 2 numeros";
  cin >> n1,n2;

}