#include <iostream>
using namespace std;
int main (){

 int x,y;

    cout << "da x\n";
    cin >> x;
    cout << "manda o y ai\n";
    cin >> y;



    cout << x + y ;

}