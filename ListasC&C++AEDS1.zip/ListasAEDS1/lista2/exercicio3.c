/*considere a seguinte definição de ano bissexto (ano em que o mês de fevereiro
tem 29 dias):
● Um ano não divisível por 100 e divisível por 4 é bissexto;
● Um ano divisível por 400 é bissexto;
● Os demais anos nãosão bissextos.
Escreva um programa que recebe o ano do usuário e imprime se o ano é bissexto.
*/
#include<stdio.h>
int main (void){
    
    int ano;

    printf("entre com o ano desejado\n");
    scanf("%d",&ano);

    if (ano % 400 == 0)
        {
            printf("o ano e bissexto");
        }
        else if (ano % 100 != 0 && ano % 4 == 0)
        {
            printf("o ano e bissexto");
        }
            else 
            printf("o ano n e bissexto");

        return (0);

    }