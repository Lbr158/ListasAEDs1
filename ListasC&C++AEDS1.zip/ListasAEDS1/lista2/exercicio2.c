/*Escreva um programa que receba de entrada a altura, o peso e o sexo de uma
pessoa e informe se ela está acima do seu peso ideal. Informe também o peso
ideal para a sua altura.
Para homens: (72.7 𝑥 𝑎𝑙𝑡𝑢𝑟𝑎)−58
Para mulheres: (62.1 𝑥 𝑎𝑙𝑡𝑢𝑟𝑎)−44.7
*/


#include<stdio.h>
int main (void){

    int peso,sexo;
    float altura,pesoideal;
    printf("entre com seu peso\n");
    scanf("%d",&peso);
    printf("entre com sua altura\n");
    scanf("%f",&altura);
    printf("entre com seu sexo 1 para masculino e 2 para feminino\n");
    fflush(stdin);
    scanf("%d",&sexo);

      switch(sexo){
          case 1: pesoideal=(72.7*altura)-58;

    
            break;
         case 2: pesoideal=(62.1*altura)-44.7;
    
             break;

        default:  printf("opcao invalida\n");
        return(0);
    
    }
    if (pesoideal > peso){
        printf("voce esta abaixo do peso\n");
        printf("seu peso ideal :%2.f",pesoideal);
    }
    else if (pesoideal < peso)
     {
        printf("voce esta a cima do peso\n");
        printf("seu peso ideal :%2.f",pesoideal);
    }
    else {
        printf("voce esta no seu peso ideal");
    }

return (0);
}