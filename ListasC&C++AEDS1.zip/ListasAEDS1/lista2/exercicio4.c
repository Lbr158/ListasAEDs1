/*Faça um algoritmo que segundo uma nota informada pelo usuário, verifique em qual
faixa a mesma se encaixa e imprima para o usuário a mensagem correspondente
conforme a tabela abaixo
:Faixa das notasMensagem
Nota > = 8 e Nota < = 10 Ótimo
Nota > = 7 e Nota < 8 Bom
Nota > = 5 e Nota < 7 Regular
Nota < 5 Insatisfatório
*/

#include<stdio.h>
int main (void){

    float nota;

    printf("entre com sua nota\n");
    scanf("%f",&nota);

    switch (nota)
    {
        case 1:
            printf("insatisfatorio");
            break;
        case 2:
            printf("insatisfatorio");
            break;
        case 3:
            printf("insatisfatorio");
            break;
        case 4:
            printf("insatisfatorio");
            break;
        case 5:
            printf("regular");
            break;
        case 6:
            printf("regular");
            break;
        case 7:
            printf("bom");
            break;
        case 8:
            printf("otimo");
            break;
        case 9:
            printf("otimo");
            break;
        default :
            printf("otimo");
            break;
    }
    return(0);
        
}