/*Um hotel com 75 apartamentos deseja fazer uma promoção especial de final de
semana, concedendo um desconto de 25% na diária. Com isto, espera aumentar sua taxa
de ocupação de 50 para 80%. Sendo dado o valor normal da diária, calcular e imprimir:
● o valor da diária promocional;
● o valor total arrecadado com 80% de ocupação e diária promocional;
● o valor total arrecadado com 50% de ocupação e diária normal;
● a diferença entre estes dois valores.
*/
#include<stdio.h>
int main (void){

    float diaria,valorpromo,desconto,oitentapromo,cinquentanor,dif;
    printf("entre com o valor da diaria\n");
    scanf("%f",&diaria);

    desconto = (diaria / 100)*25 ;
    valorpromo = diaria - desconto;
    oitentapromo = (valorpromo * 60)*2;  // entendendo que o total arrecadado seja o final de semana sabado e domingo
    cinquentanor = (diaria * 37.5)*2 ; // pensando 50% de 75 matematicamente pq n da pra alugar meio quarto XD 
    dif = oitentapromo - cinquentanor;

    printf("a diaria promocional e : %1.f\n",valorpromo);
    printf(" o valor total arrecadado com 80 porcento de ocupacao e diaria promocional: %1.f\n",oitentapromo);
    printf("o valor total arrecadado com 50 porcento de ocupacao e diaria normal: %1.f\n",cinquentanor);
    printf("a diferenca entre eles e :%1.f",dif);

    return (0);






}