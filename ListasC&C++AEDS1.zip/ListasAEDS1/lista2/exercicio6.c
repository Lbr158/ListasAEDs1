/*Construa um programa que lê uma opção conforme abaixo (usar estrutura SWITCH) e o
salário atual do funcionário, calcula e exibe o novo salário:
A = aumento de 8% no salário;
B = aumento de 11% no salário;
C = aumento fixo no salário
(de R$ 350,00 se o salário atual for até R$1000 e de R$200,00 se o salário atual for maior
que R$ 1000).
*/
#include<stdio.h>
int main (void){
    int op;
    float sal1,sal2,variavel;

    printf("entre com seu salario\n");
    scanf("%f",&sal1);
    printf("entre com sua opcao 1 para A,2 para B ou 3 para C\n");
    scanf("%d",&op);

    switch (op)
    {
        case 1:
            variavel = (sal1 / 100)*8;
            sal2 = sal1 + variavel;
            printf("seu novo salario : %2.f",sal2);
            break;
        return(0);

        case 2:
            variavel = (sal1 /100)*11;
            sal2= sal1 + variavel;
            printf("seu novo salario : %2.f",sal2);
            break;
            return(0);

        case 3:
            if (sal1 <= 1000)
            {
                sal2 = sal1 + 350;
                printf("seu novo salario :%2.f",sal2);
            }
            else 
               {
                sal2 = sal1 + 200;
                printf("seu novo salarui : %2.f",sal2);
               }
            break; 
        }  
    return(0);

    }