/* escreva um programa que solicita ao usuario um numero positivo inteiro de 4 algarismos,
 verifica se o valor possui 4 algarismos e imprime o seu valor invertido
*/

#include<stdio.h>
int main (void){

    //criando a variavel e salvando um numero de 4 digitos nela

    int num;
    printf("entre com um numero inteiro de 4 algarismos\n");
    scanf("%d",&num);

    //verificacao do tamanho

    if (num > 999 && num < 10000){
        printf("seu numero tem 4 digitos\n");
    }
    else {
        printf("seu numero não é valido");

        return (0);
    }
    //inversão do numero

    int uni = num % 10;
    int num2 = num / 10;
    int dec = num2 % 10;
    int dec2 = num2 / 10;
    int cen = dec2 % 10;
    int cen2 = dec2 / 10;
    int mil = cen2 % 10;

    //imprimindo o numero invertido

    printf("seu numero invertido : %d%d%d%d",uni,dec,cen,mil);
    return (0);
}