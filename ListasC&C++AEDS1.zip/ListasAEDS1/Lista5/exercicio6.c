/*Faça um procedimento recursivo que receba dois valores inteiros a e b e imprima o
intervalo fechado entre eles. Se a > b imprima uma mensagem de erro.
*/
//Recursão que calcula e imprime os numeros
void intervalo(int a,int b){
    
    if (a == b) {
        printf("%d",a);
    } 
    else return intervalo(a,b-1);
}
//Criação de salva de variaveis + chamada da recursão
int main(void){
    int a,b;
    printf("entre com os numeros");
    scanf("%d %d",&a,&b);
    if (a > b){
        printf("primeiro numero maior que o segundo,erro");
        return(0);
    }
    else
    intervalo(a,b);
    return(0);
}