/*Faça uma função em C para contar os dígitos de um determinado número usando
recursão. Faça um programa principal que leia um número, acione a função e exiba o
resultado gerado.
*/
#include<stdio.h>
//calculo de recursão para calcular o numero de digitos de um numero
int calculodigitos (int n){
    if (n<10) return 1;
    else return calculodigitos(n/10)+1;

}
// criação e salva de variaveis + retorno de calculodigitos
int main (void){
    int n,digitos;
    printf("entre com o numero\n");
    scanf("%d",&n);
    digitos = calculodigitos(n);
    printf("%d",digitos);
    return (0);
}