/*Faça uma função recursiva que calcula o valor de S da série a seguir para n > 0:
S = 1/1! + 1/2!  + 1/3! + ...+1 /N!
double serie (int n)
Faça um programa principal que leia um número, acione a função e exiba o resultado
gerado.
*/
//Calculo de recursão do fatorial
#include<stdio.h>
double fatorial(int n){
    if (n==1)return 1;
    else return fatorial(n-1)*n;

}
//Calculo de recursão da solução
double solucao(int n){
    if (n == 1)return 1;
    else return 1/fatorial(n)+solucao(n -1);


}
//Criação e salva de variaveis + retorno das recursões
int main(void){
    int n,calculo;
    double serie;
    printf("entre com um numero");
    scanf("%d",&n);
    calculo = fatorial(n);
    serie = solucao(n);
    printf("%lf",serie);
    return(0);
}
