/*Faça uma função recursiva que calcula a divisão usando subtrações sucessivas:
int divisao (int numerador, int denominador)
Faça um programa principal que leia dois números, acione a função e exiba o resultado
gerado.
*/
#include<stdio.h>
//calculo de recursão onde ele encontra o numero de vezes que um numero divide pelo outro
int divisãodenumeros (int n1,int n2){
    printf("%d %d\n",n1,n2);
    if (n2 > n1)return 0;
    else return divisãodenumeros(n1 - n2,n2)+1;
}
//criação e salva de variaveis + retorno de divisodenumeros
int main (void){
    int n1,n2,resultado;
    printf("entre com os numeros\n");
    scanf("%d %d",&n1,&n2);
    resultado = divisãodenumeros(n1,n2);
    printf("%d",resultado);
    return (0);
}