/*Faça uma função recursiva que calcula o resto da divisão usando subtrações sucessivas:
int resto (int numerador, int denominador)
Faça um programa principal que leia dois números, acione a função e exiba o resultado
gerado.
*/
#include<stdio.h>
//calculo de recursão onde ele encontra o resto de uma subitração sucessiva
int resto (int numerador,int denominador){
    if (numerador < denominador)
    return numerador;
    else return resto(numerador - denominador,denominador);
}
//criação e salva de variaveis + retorno de resto
int main(void){
    int a,b,restoo;
    printf("entre com os numeros\n");
    scanf("%d %d",&a,&b);
    restoo = resto(a,b);
    printf("%d",restoo);
    return(0);
}