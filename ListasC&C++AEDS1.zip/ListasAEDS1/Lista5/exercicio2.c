/*Faça uma função para encontrar a soma dos dígitos de um número usando recursão. Faça
um programa principal que leia um número, acione a função e exiba o resultado gerado.
*/
#include<stdio.h>
//calculo de recursão que calcula a soma dos digitos de um numero
int somadenumeros (int n){
    if (n < 10) return n;
    else return somadenumeros(n/10)+n%10;

}
//criação e salva de variaveis + retorno de somadenumeros
int main(void){
    int n,soma;
    printf("entre com o numero");
    scanf("%d",&n);
    soma = somadenumeros(n);
    printf("%d",soma);
    return(0);
}