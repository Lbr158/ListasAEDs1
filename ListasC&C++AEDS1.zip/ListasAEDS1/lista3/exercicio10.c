/*Em uma eleição presidencial existem quatro candidatos. Os votos são informados através
de códigos. Os dados utilizados para a contagem dos votos obedecem à seguinte
codificação:
1,2,3,4 = voto para os respectivos candidatos;
5 = voto nulo;
6 = voto em branco;
Elabore um algoritmo que leia o código do candidado em um voto. Calcule e escreva:
- total de votos para cada candidato;
- total de votos nulos;
- total de votos em branco.
Como finalizador do conjunto de votos, tem-se o valor 0.
*/
#include<stdio.h>
int main(void){
    //declaração de variaveis
    int voto,i,v1 = 0,v2 = 0,v3 = 0,v4 = 0,vnulo = 0,vbranco = 0;
    //solicitação de um valor + salvar esse valor dentro de uma variavel
    printf("quantas pessoas vao votar ?\n");
    scanf("%d",&voto);
    //repetição
    for ( i = 0; i <= voto; i++)
    {
        printf("entre com o numero do candidato escolhido 1,2,3 ou 4 sendo 5 nulo e 6 branco\n");
        scanf("%d",&voto);

        if (voto == 1)
        {
            v1++;
        }
        if (voto == 2)
        {
            v2++;
        }
        if (voto == 3)
        {
            v3++;
        }
        if (voto == 4)
        {
            v4++;
        }
        if (voto == 5)
        {
            vnulo++;
        }
        if (voto == 6)
        {
            vbranco++;
        }
    }
    printf("VOTOS\n 1:%d\n 2:%d\n 3:%d\n 4:%d\n nulos:%d\n em branco: %d\n",v1,v2,v3,v4,vnulo,vbranco);
    
    return (0);
}
//por algum motivo ele n funciona as vezes, reiniciar o vscode resolve as vezes tbm kkkkk n sei explicar
