/*Escreva um algoritmo que lê um valor n inteiro e positivo e que calcula a seguinte soma:
S = 1 + 1/2 + 1/3 + 1/4 + ... + 1/n
O algoritmo deve escrever cada termo gerado e o valor final de S.
*/
#include<stdio.h>
int main (void){
    //declaração de variaveis int e flutuantes
    int n,i;
    float fatorial = 1,conta;
    //solicitação de um valor + salvar esse valor dentro de uma variavel
    printf("entre com N\n");
    scanf("%d",&n);
    //calculo do fatorial mais o extra
      fatorial = 1;

        for(i=1; i<=n; i++){

            fatorial = fatorial * i;

             conta = conta + (1/fatorial);
            printf("%d + (1/%d\n",conta,fatorial);

            }
        printf("O valor de final e: %d ", conta);
    
    return (0);

}