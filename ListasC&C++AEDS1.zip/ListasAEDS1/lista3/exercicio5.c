/*A prefeitura de uma cidade fez uma pesquisa entre seus habitantes, coletando dados sobre
o salário e número de filhos de cada habitante. A prefeitura deseja saber:
a) média do salário da população;
b) média do número de filhos;
c) maior salário;
d) percentual de pessoas com salário até R$100,00.
O final da leitura de dados se dará com a entrada de um salário negativo.
*/

#include<stdio.h>
int main(void){
    //declaração de variaveis
    int i,salarioate100 = 0,salario = 0,salariogeral = 0,maiorsalario = 0,numerodefilhos,numerodefilhosgeral = 0,nhabitantes,percentualsalario;
     //solicitação de um valor + salvar esse valor dentro de uma variavel
    printf("entre com o numero de habitantes\n");
    scanf("%d",&nhabitantes);
    //repetição
    for ( i = 0; i < nhabitantes; i++)
    {
        printf("entre com seu salario\n");
        scanf("%d",&salario);
        salariogeral = salario + salariogeral;
        if (salario <= 100)
        {
            salarioate100++;
        }
        if (salario < 0)
        {
            break;
        }

        if (salario > maiorsalario)
        {
            maiorsalario = salario;
        }
        
        printf("entre com o numero de filhos que vc tem\n");
        scanf("%d",&numerodefilhos);

        numerodefilhosgeral = numerodefilhosgeral + numerodefilhos;

    }
    //calculo de media e %
    int mediasalarial = salariogeral / nhabitantes ;
    int mediafihlos = numerodefilhosgeral / nhabitantes;
    percentualsalario = (salarioate100 / nhabitantes)*100;

    printf("a media do salario da populacao :%d\n",mediasalarial);
    printf("a media de filhos da populacao :%d\n", mediafihlos);
    printf("o maior salario :%d\n",maiorsalario);
    printf("o percentual de pessoas com salario ate 100 e : %d%%",percentualsalario);

    return(0);
}