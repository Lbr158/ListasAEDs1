//Faça um programa que imprima todos os elementos da série de Fibonacci menores que L.
#include<stdio.h>
int main(void){
    //declaração de variaveis
    int i,n,fib2 = 1,fib1 = 1,variavel= 1;
    //solicitação de um valor + salvar esse valor dentro de uma variavel
    printf("entre com o numero limitador\n");
    scanf("%d",&n);

// loop infinito
    for ( i = 0; i < n; i--)
    {
    if (variavel >= n)
    {
        return (0);
    }
        
        printf("%d\n",variavel);
        variavel = fib1 + fib2;
        fib1 = fib2;
        fib2 = variavel;
    
    }
    return (0);
}