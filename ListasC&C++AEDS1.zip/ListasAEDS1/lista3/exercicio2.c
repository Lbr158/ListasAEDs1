/*Adaptar o programa acima para que ele calcule o percentual dos valores positivos,
negativos e zeros em relação ao total de valores fornecidos.
*/
#include<stdio.h>
int main (void){
    //declaração de inteiros
    int n0 = 0;
    int npositivos = 0;
    int nnegativos = 0;
    int nvalores;
    int n;
    //solicitação de um valor + salvar esse valor dentro de uma variavel
    printf("entre com o numero de valores\n");
    scanf("%d",&nvalores);
    //repetição
    while (nvalores > 0)
    {
 
         printf("entre com o valor\n");
         scanf("%d",&n);

    if (n > 0)
    {
        npositivos = npositivos + 1;
        nvalores--;
    }
    else if (n < 0)
    {
        nnegativos = nnegativos + 1;
        nvalores--;
    }
    else
    {
        n0 = n0 +1;

        nvalores--;
    }

    }

    printf("numero de positivos :%d\n numero de negativos: %d\n numero de zeros : %d\n",npositivos,nnegativos,n0);

//calculo de % + declaração de flutiantes
float npositivosp,nnegativosp,n0p;
int ntotal = npositivos + nnegativos + n0;

npositivosp = (npositivos / (float)ntotal)*100;
nnegativosp = (nnegativos / (float)ntotal)*100;
n0p = n0 / ((float)ntotal)*100;

printf("agr em porcentagem \n numero de positivos :%1.f \n numeros negativos %1.f \n numeros negativos %1.f  ",npositivosp,nnegativosp,n0p);




return (0);


}
