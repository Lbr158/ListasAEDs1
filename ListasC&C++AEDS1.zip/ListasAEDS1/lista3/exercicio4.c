/*Escrever um algoritmo que lê um valor N inteiro e positivo e que calcula e escreve o valor
de E:
E = 1 + 1 / 1! + 1 / 2! + 1 / 3! + .... + 1 / N!
*/
#include<stdio.h>
int main (void){
    //declaração de variaveis int e flutuantes
    int n;
    float fatorial = 1,conta;
    //solicitação de um valor + salvar esse valor dentro de uma variavel
    printf("entre com N\n");
    scanf("%d",&n);
    //calculo do fatorial mais o extra
      fatorial = 1;

        while (n<=1)
            {
            fatorial = fatorial * i;

             conta = conta + (1/fatorial);
            n--;
            }
        printf("O valor de E: %d ", conta);
    
    return (0);

}