/*Faça um programa que imprima os L primeiros elementos da série de Fibonacci. Por
exemplo, se o usuário digitou o número 40, deverão ser apresentados os 40 números da
sequência na tela.
*/
#include<stdio.h>
int main(void){
    //declaração de variaveis
    int i,n,fib2 = 1,fib1 = 1,variavel= 1;
    //solicitação de um valor + salvar esse valor dentro de uma variavel
    printf("entre com o numero da serie que vc deseja\n");
    scanf("%d",&n);
     //repetição
    for ( i = 0; i < n; i++)
    {
        
        printf("%d\n",variavel);
        variavel = fib1 + fib2;
        fib1 = fib2;
        fib2 = variavel;
    }
 return (0);   
}
