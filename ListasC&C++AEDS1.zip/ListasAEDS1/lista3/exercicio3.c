/*Faça um programa que receba dez números e verifique se eles são divisíveis por 3 e 9 (ao
mesmo tempo), por 2 e por 5. Caso algum número não seja divisível por nenhum desses
números mostre a mensagem “Número não é divisível pelos valores”. Apresente também
ao final a quantidade de números divisíveis por 3 e 9, por 2 e por 5.
*/
#include<stdio.h>
int main (void){
    //declaração de variaveis 
    int n,i,contador1 = 0,contador2 = 0;
    //repetição especifica de 10 
    for (i = 0; i < 10; i++)
    {
        printf("entre com o numero\n");
        scanf("%d",&n);
        if (n % 3 != 0 || n % 9 != 0)
        {
            printf("Numero nao e divisivel por 3 e 9 ao mesmo tempo\n");
        }
        else
        {   
            contador1++;
        }
        if (n % 2 != 0 || n % 5 != 0)
        {
             printf("Numero nao e divisivel por 2 e 5 ao mesmo tempo\n");
        }
        else
        {   
            contador2++;
        }
    }
    
    printf("%d sao divisiveis por 3 e 9 e %d sao divisiveis por 2 e 5\n",contador1,contador2);

return (0);
}