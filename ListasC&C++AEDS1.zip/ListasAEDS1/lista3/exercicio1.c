/*Fazer um programa leia uma seqüência de valores inteiros fornecida pelo usuário em uma
linha de entrada e conte o número de valores positivos, negativos e zeros.
*/
//perguntar ao usuario quantos valores serão fornecidos

#include<stdio.h>
int main (void){
    //declarando variaveis 
    int n0 = 0;
    int npositivos = 0;
    int nnegativos = 0;
    int nvalores;
    int n;
    //pedindo um valor e salvando ele dentro de uma variavel
    printf("entre com o numero de valores");
    scanf("%d",&nvalores);
    //repetição
    while (nvalores > 0)
    {
 
         printf("entre com o valor");
         scanf("%d",&n);

    if (n > 0)
    {
        npositivos = npositivos + 1;
        nvalores--;
    }
    else if (n < 0)
    {
        nnegativos = nnegativos + 1;
        nvalores--;
    }
    else
    {
        n0 = n0 +1;

        nvalores--;
    }

    }

    printf("numero de positivos :%d\n numero de negativos: %d\n numero de zeros : %d\n",npositivos,nnegativos,n0);

return (0);


}

