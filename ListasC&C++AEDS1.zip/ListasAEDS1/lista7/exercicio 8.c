/* Faça um programa que leia três valores inteiros e chame uma função que receba o endereço destes 3 valores de entrada e retorne eles ordenados, ou seja, o menor valor na primeira variável, o segundo menor valor na variável do meio, e o maior valor na última variável. A função deve retornar o valor 1 se os três valores forem iguais e 0 se existirem valores diferentes. Exibir os valores ordenados na tela no programa principal. */ 

#include <stdio.h>
#include <stdlib.h>

int compara(int num1, int num2, int num3)
{
      if(num1 > num2 && num2 > num3)
      {
        printf("%d %d %d",num1,num2,num3);
        return 0;
      }
      if (num1 > num2 && num3 > num2)
      {
        printf("%d %d %d",num1,num3,num2);
        return 0;
      }
      if(num2 > num1 && num1 > num3)
      {
        printf("%d %d %d",num2,num1,num3);
        return 0;
      }
      if (num2 > num1 && num3 > num1)
      {
        printf("%d %d %d",num2,num3,num1);
        return 0;
      } 
      if(num3 > num2 && num2 > num1)
      {
        printf("%d %d %d",num3,num2,num1);
        return 0;
      }
      if (num3 > num2 && num1 > num2)
      {
        printf("%d %d %d",num3,num1,num2);
        return 0;
      } 
      if (num1 == num2 && num2 == num3)
      {
        return 1;
      }
      

        }

int main(){
  int num1,num2,num3,retorno = 0;
  printf("entre com os numeros");
  scanf("%d %d %d",&num1,&num2,&num3);
  retorno = compara(&num1,&num2,&num3); //Chamar função
  return 0;
}