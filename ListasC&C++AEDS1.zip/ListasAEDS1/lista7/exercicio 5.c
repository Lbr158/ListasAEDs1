/* Escreva um programa em C que declare variáveis para armazenar um valor inteiro, um valor real e um caracter. Deve existir no programa ponteiros associados a cada um deles.  O programa deve solicitar novos dados para as variáveis e elas devem ser modificadas usando os respectivos ponteiros. Exiba os endereços e os conteúdos de todas as variáveis e ponteiros antes e após a alteração. */

#include <stdio.h>

int main(void) {
  int v1 = 20, *n1;
  char v2 = 'r', *n2;

  n1 = &v1;
  n2 = &v2;
  printf("v1 = %d -> Endereço = %p\nv2 = %c -> Endereço = %p", v1, &v1, v2, &v2);


  //Novos valores digitados pelo usuario
  printf("\nNovo valor de v1:\n");
  scanf("%d", n1);
  printf("\nNovo valor de v2:\n");
  scanf(" %c", n2);

  printf("\n\nNovo valor de v1 = %d -> Endereço = %p\nNovo valor de v2 = %c -> Endereço = %p", v1, &v1, v2, &v2);
 
  return 0;
}