/* Escreva um programa em C que leia dois inteiros, armazenando-os em variáveis. O programa deve comparar os endereços das variáveis e exibir o maior deles. */ 

#include <stdio.h>

int main(void) {

  int n1, n2;

printf("Digite dois valores\n");
scanf("%d %d", &n1, &n2);

printf("Endereço 1 %p\nEndereço 2 %p\n\n", &n1, &n2); // imprime o endereço das posições de memoria
   
if (&n1 > &n2) // condição de comparação 
  printf("O N1 é maior %p", &n1);
else
  printf("N2 é maior %p", &n2);

  
  return 0;
}