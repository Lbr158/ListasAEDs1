/*  Explique cada uma das expressões a seguir, indicando a diferença entre elas:
p++;
(*p)++;
*(p++);
Qual informação se refere a expressão *(p+10)? */

#include <stdio.h>

int main(void) {
  printf("Qual a diferença entre: \np++\n(*p)++\n*(p++)\n\n\nResposta\n");
  printf("p++ = incrementa +1 na variavel p\n\n");
  printf("(*p)++ =  Incrementa o conteúdo apontado por p, ou seja, o valor armazenado na variável para qual p está apontando\n\n");
  printf("*(p++) = Incrementa p (como em p++) e acessa o valor encontrado na nova posição. Se em um vetor, esta expressão acessa o valor da posição imediatamente superior a armazenada em p antes do incremento. \n\n");
  return 0;
}