/*Identifique o erro no programa a seguir, de modo que seja exibido o valor 10 na tela.

#include <stdio.h>
int main()
{
int x, *p, **q;
p = &x;
q = &p;
x = 10;
printf("\n%d\n", &q);
return(0);
}

teste de mesa
memoria  variavel  conteudo
  120      p         &x
  121      q         &p
  122      x         10

p=120
q=120
x=10


*/ 

#include <stdio.h>

int main(void) {
  
int x, *p=0, **q=0;
p = &x;
q = &p;
x = 10;
printf("\n%d\n\n", **q);
  printf("O erro está na linha 35 (printf), visto que o mesmo não está apontando para o ponteiro de x, o certo é o valor apontado pelo valor apontado por q, ou seja **q");
  
return(0);
}
