/* Observe os dois programas a seguir, Código 1 e Código 2. Qual. É a diferença entre eles?

Qual é o valor impresso para ptr em cada um dos códigos? Porque? */

#include <stdio.h>
#include <stdlib.h>

int main(void) {
  printf("Código 1\n");
  int *ptr, i;
  
  ptr = (int *) malloc(sizeof(int));
  *ptr = 10;
    for(i=0;i<5;i++){
    *ptr=*ptr+1;
    }
    printf("\nptr: %d\n\n", *ptr);
    free(ptr);
    printf("O código 1 imprime o conteudo de ponteiro de ptr\n\n");

  
  printf("Código 2\n");
      
      ptr = (int *) malloc(sizeof(int));
      *ptr = 10;
        for(i=0;i<5;i++){
        ptr=ptr+1;
        }
        printf("\nptr: %p\n\n", ptr);
        
        printf("O código 2 imprime o endereço de memoria, porém, da erro pois só foi alocado 1 endereço, e no código ele incrementa +1");
        free(ptr);
  
return 0;
}
