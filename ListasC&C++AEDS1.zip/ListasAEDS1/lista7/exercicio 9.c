#include <stdio.h>
/* Teste de mesa

Resolução

x   y  px  py
5   6  &x  &y
5   6  &y  &y
5   36 &y  &y
5   38 &y  &y 

*/
void func(int *px, int *py)
    {
      px = py;
      *py = (*py) * (*px);
      *px = *px + 2;
    }

  int main ()
  {
  int x=5, y=6;
  func(&x, &y);
  printf("x = %d, y = %d", x, y);
          
return 0;
}