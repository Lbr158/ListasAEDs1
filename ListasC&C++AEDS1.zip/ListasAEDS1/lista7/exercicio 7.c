/* Faça um programa que leia dois valores inteiros e chame uma função que receba o endereço destes 2 valores de entrada e retorne o maior valor na primeira variável e o menor valor na segunda variável. Escreva o conteúdo das 2 variáveis na tela no programa principal. */

#include <stdio.h>
#include <stdlib.h>

void compara(int *num1, int *num2)
{
      int aux = 0; //Variavel auxiliar
      if(*num2 > *num1) //Verificação de valores e condiçaõ de maior / menor
   {
      aux = *num2; // num2 = 90 && num1 80
      *num2 = *num1; // 90 = 80
      *num1 = aux; // 80 = 90
      
   }
  
}

int main(){
   int num1=0, num2=0;
     printf("\n Digite o primeiro valor: ");
     fflush(stdin);
     scanf("%d", &num1);
     printf("\n Digite o segundo valor: ");
     fflush(stdin);
     scanf("%d", &num2);
     compara(&num1,&num2); //Chamar função
   
  //print de valores
   printf("\n\n Maior valor: %d", num1);
   printf("\n\n Menor valor: %d\n\n", num2);
   
   return 0;

}

