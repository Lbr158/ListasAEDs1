/* 
Se o endereço de uma variável valor foi atribuído a um ponteiro valorPtr, quais alternativas são verdadeiras? Justifique sua resposta.

a) valor = = &valorPtr - Errada, porque o valor da variavel valor é diferente do endereço da posição de memoria.

b) valor = = *valorPtr - 

c) valorPtr = = &valor - 

d) valorPtr = = *valor -
valorptr = &valor

*/
Teste de mesa
memoria  variavel  conteudo
120        valor      10
121      *valorPtr   120


testes
a) valor = = &valorPtr
  // Falsa, o endereço de memoria de um ponteiro não equivale ao conteudo da variavel para qual ele aponta.  
  
b) valor = = *valorPtr
  // Verdadeira, pois o valor da variavel valor é o mesmo que o ponteiro está apontando. (10).

c) valorPtr = = &valor
 // Verdadeiro, pois o valor do endereço de memoria é o mesmo. (posição de memoria 120 é igual a 120).

d) valorPtr = = *valor
 // Falso, porque o operador do * só pode ser usado como ponteiro. 

  return 0;
}