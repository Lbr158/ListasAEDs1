/*Escreva uma função chamada contaVogais que recebe uma frase e retorna a
quantidade de vogais na frase. Lembre-se de contar tanto maiúsculas quanto minúsculas.
Exemplo
Entrada:
O rato roeu a roupa do rei de roma.
Saída:
16
*/
#include<stdio.h>
int contavogais (char frase){
    
}