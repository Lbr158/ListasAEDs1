/* Faça um algoritmo que leia e armazene uma sequência de no máximo 50 inteiros e
imprima na forma de tabela os números pares presentes na sequência, bem como o
valor dos seus índices no vetor. Dica: o caractere ‘\t’ de tabulação pode ser usado para
formatar o espaçamento como tabela.
Exemplo
Entrada:
1 3 8 12 9 7 -5 -6 21
Saída:
Valores Índices
8 2
12 3
-6 7

*/
#include <stdio.h>
#define TAM_MAX 50 

int main(){
int i, aux, n, vetor[TAM_MAX]; // Declaração de variaveis e vetor. O valor o vetor foi definido no inicio do cód. (#Define...)
printf("Para encerrar, digite qualquer número negativo. (-1, -2, -55..)\n");
  for(i=0; i < TAM_MAX; i++){ // enquanto o valor de i for 0 e menor que o vetor TAM_MAX repita o laço
    printf("Digite o %dº valor\n", i+1); // solicitação de entrada de dados pelo usuario. 
    scanf("%d", &aux); // leitura de dados e armazenamento na variavel auxiliar
    if(aux <=0) break; // condição de parada
    vetor[i] = aux; // 
    }
  
    n = i; //contador 
  
    printf("Valores (par) \t Indices (impar)\n");
  
      for (i=0; i<n; i++){ //Quando a repetição anterior encerrar, execute essa. i=0,
        if(vetor[i]%2 ==0){ // verificação se o número é par. // Se for divisivel por 2 é par
          printf("\t%d \t\t\t\t %d\n", vetor[i], i); // imprima na tela vetor e a quantidade de repetições (indice)
        }
      
      }
 
return 0;
}