/* Faça um programa que leia e armazene 2 sequências de no máximo 100 inteiros cada.
Em seguida imprima:
● A soma de cada elemento das duas sequências, nas respectivas posições
● A soma de cada elemento da primeira sequência com a segunda sequência
invertida.
Nota: As sequências de entrada podem não ter o mesmo tamanho. Iguale o tamanho das
duas sequências preenchendo com zeros.
Passo 1: Leia duas sequências
1 5 7 3 22 0 11
3 9 56
Passo 2: Iguale o tamanho das sequências
1 5 7 3 22 0 11
3 9 56 0 0 0 0
Passo 3: Calcule e imprima os requisitos da questão
Soma: 4 14  63 3 22 0 11
Soma invertida: 1 5 7 3 78 9 14
*/

#include<stdio.h>
#define TAM_MAX 100

int main(void){
    int i, aux, soma, sequencia[TAM_MAX],sequencia2[TAM_MAX];
    for(i=0; i < TAM_MAX; i++){
    sequencia[i] = 0;
    }
    for(i=0; i < TAM_MAX; i++){
    sequencia2[i] = 0;
    }
    printf("Para encerrar, digite qualquer número negativo. (-1, -2, -55..)\n");
    for(i=0; i < TAM_MAX; i++){ 
    printf("Digite o %dº valor\n", i+1); 
    scanf("%d", &aux); 
    if(aux <=0) break; 
    sequencia[i] = aux;  
    }    
    printf("Para encerrar, digite qualquer número negativo. (-1, -2, -55..)\n");
    for(i=0; i < TAM_MAX; i++){ 
    printf("Digite o %dº valor\n", i+1); 
    scanf("%d", &aux); 
    if(aux <=0) break; 
    sequencia2[i] = aux;  
    }
    printf("somas :\t")
    for(i=0;i< TAM_MAX;i++){
        soma = sequencia[i] + sequencia2[i];
        printf("%d\t",soma);
    }    
}