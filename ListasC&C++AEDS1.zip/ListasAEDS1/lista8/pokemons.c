#include<stdio.h>
int main (void){
char **meus_pokemons;
int *meus_pokemons;
printf("entre com o numero de pokemons que você tem");
scanf("%d",&n);
meus_pokemons = (int *) malloc( n * sizeof(int*));
for (int i; i = 0; i < n; i++)
{
    
}

}