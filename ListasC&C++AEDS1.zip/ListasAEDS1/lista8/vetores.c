#include<stdio.h>
#define TRUE = 1
#define FALSE = 0
int aloca (int n, int preenche){
    if (preenche == TRUE)
    {
        vetor = (int*) calloc (n*,sizeof(int));
    }
    if (preenche == FALSE)
    {
        vetor = (int*) malloc (n*,sizeof(int));
    }
    return vetor;
}
void imprime (int v[], int n){
    int aux = 0;
    printf("%d",v[0]);
    for (int i; i = 0; i < n; i++)
    {
       printf("%d",v[aux +1]);
       aux++;
    }
    
}
void preenche (int v[],int n,int valor,int is_aleatorio){
    if (is_aleatorio == TRUE)
    {
        for(int i;i = 0; i < n; i++)
         {
         vet[i] = rand();
         }
    }
    if (is_aleatorio == FALSE)
    {
        for (int i; i = 0; i < n; i++)
        {
          vet[i]=  valor;
        }
        
    }
    
}
int inverte (int v[],int n){
    int vinvertido[];
    for (int i; i = 0; i < n; i++)
    {
        vinvertido[i] = v[n - i - 1];
    }
    return vinvertido;
}
int main(void){
 int v1*,v2*;
   v1 = aloca(10,0);
   v2 = aloca(10,1);
   for (int i; i = 0; i < 10; i++)
   {
       printf("%d",v1[i]);
       printf("%d",v2[i]);
   }
   v1 = preenche(v1[],10,0,1);
   for (i = 0; i < count; i++)
   {
       printf("%d",v1[i]);
   }
   v1 = inverte(v1[],10);
   v2 = inverte(v1[],10);
   for (int i; i = 0; i < 10; i++)
   {
       printf("%d",v1[i]);
       printf("%d",v2[i]);
   }
}