/*Faça um procedimento que recebe as 3 notas de um aluno por parâmetro e uma letra. Se a
letra for ‘A’, o procedimento calcula e escreve a média aritmética das notas do aluno, se
for ‘P’, calcula e escreve a sua média ponderada (pesos: 5, 3 e 2). Faça um programa que
leia 3 notas de N alunos e acione o procedimento para cada aluno. (N deve ser lido do
teclado)
*/

#include<stdio.h>
//ininio do procedimento de calculo da nota
void calculonota (char letra,int n1, int n2, int n3){
float media;
    if (letra == 'a')
    {
        media = (n1 + n2 + n3)/3;
        printf("sua media e:%2.f\n",media);
    }
    else if (letra == 'p')
    {
        media = (n1 + n2 + n3)/(5 + 3 + 2);
        printf("sua media ponderada:%2.f\n",media);
}
}
int main (void){
    int i,n,n1,n2,n3;
    char a;
    printf("entre com o numero de alunos\n");
    scanf("%d",&n);
    for(i = 0;i < n;i++){
      printf("entre com suas notas\n");
      scanf("%d %d %d",&n1,&n2,&n3);
      printf("entre com a opcao A ou P\n");
      scanf(" %c",&a);
      
      calculonota (a, n1, n2, n3);
    }
    

return(0);
}