/*Faça uma função que lê um número indeterminado de notas de alunos, calcula e retorna a
média das notas dos alunos aprovados (nota maior ou igual a 6). Faça um programa que lê
o número de alunos e imprime a média retornada pela função.
*/
#include<stdio.h>
int media (int nota){
    int somanota = 0,mediaap,contador = 0;
    
    if (nota >= 6)
    {
        somanota += nota;
        contador++;
    }
    mediaap = somanota / contador;
    return (mediaap);
}
int main (void){
    int n,i,nota;
    int mediaap;
    printf("entre com o numero de alunos\n");
    scanf("%d",&n);

    for ( i = 0; i < n; i++)
    {
        printf("entre com a sua nota\n");
        scanf("%d",&nota);

    }
    mediaap = media(nota);

    printf("a media e:%d",mediaap);

    return (0);
}