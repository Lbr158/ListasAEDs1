/*A prefeitura de uma cidade fez uma pesquisa entre os seus habitantes, coletando dados
sobre o salário e número de filhos. Faça um procedimento que leia esses dados para um
número não determinado de pessoas, calcule e exiba a média de salário da população (a
condição de parada pode ser um flag ou a quantidade N). Faça um programa que acione o
procedimento.
*/
#include<stdio.h>

     void media (int s,int media, int n){
         media = s / n;
         printf("a media salarial da populacao e :%d\n",media);
     }

int main(void) {
    int n,i,salario,filhos,v;
    int md =0;
    printf("entre com o numero de habitantes\n");
    scanf("%d",&n);
    salario = 0;
    for ( i = 0; i < n; i++)
    {
        printf("entre com seu salario\n");
        scanf("%d",&v);
        printf("entre com o numero de filhos que voce tem\n");
        scanf("%d",&filhos);

        salario = salario + v;
    }
    media (salario,md,n);
    return (0);
}