/*Escreva uma função que recebe por parâmetro um valor inteiro e positivo N e retorna o
valor de S, calculado segundo a fórmula abaixo.
S = 1 + 1/1! + 1/2!  + 1/3! + ...+1 /N!
Faça um programa que leia N e imprima o valor retornado pela função.
*/
#include<stdio.h>
int contaa (int fatorial,int n){
 int conta;
 while (n<=1)
            {
            fatorial = fatorial * n;

             conta = conta + (1/fatorial);
            n--;
            }
            return(conta);
}
int main (void){
    //declaração de variaveis int e flutuantes
    int n;
    float fatorial = 1,conta;
    //solicitação de um valor + salvar esse valor dentro de uma variavel
    printf("entre com N\n");
    scanf("%d",&n);
    //calculo do fatorial mais o extra
        conta = contaa(fatorial,n);

        printf("O valor de E: %d ",conta);
    
    return (0);

}