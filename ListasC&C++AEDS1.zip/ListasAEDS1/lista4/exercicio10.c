/* Faça uma função que recebe a idade de um nadador por parâmetro e retorna a categoria
desse nadador de acordo com a tabela abaixo.
Idade (anos) Categoria

5 a 7 F
8 a 10 E
11 a 13 D
14 a 15 C
16 a 17 B
Acima de 18 A
*/
#include<stdio.h>
char categoria (int idade){
    char cat,f,e,d,c,b,a;
if (idade >= 5 && idade <= 7)
{
    cat = f;
}
else if (idade >= 8 && idade <= 10)
{
    cat = e;
}
else if (idade >= 11 && idade <= 13)
{
    cat = d;
}
else if (idade >= 14 && idade <= 15)
{
    cat = c;
}
else if (idade >= 16 && idade <= 17)
{
    cat = b;
}
else 
{
    cat = a;
}
return (cat);
}
int main (void){
    int idade;
    char categ;
    printf("entre com sua idade\n");
    scanf("%d",&idade);

    categ = categoria(idade);
    printf("%c",'categ');
    return(0);
}