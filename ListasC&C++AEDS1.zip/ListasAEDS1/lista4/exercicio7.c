/*Faça uma função que recebe um valor inteiro e verifica se o valor é positivo ou negativo.
A função deve retornar um valor lógico (true ou false). Faça um programa que lê N
números e para cada um deles exibe uma mensagem informando se ele é positivo ou não,
dependendo se foi retornado verdadeiro ou falso pela função.
*/
#include<stdio.h>
int verifica (int numero){
    int vallogico;
    if (numero > 0)
    {
        vallogico = 1;
    }
    else if (numero < 0)
    {
        vallogico = 0;
    }
    return (vallogico);
}
int main(void){
    int n,i,num,vallogico;
    printf("quantos valores serao\n");
    scanf("%d",&n);

    for ( i = 0; i < n; i++)
    {
        printf("entre com o numero\n");
        scanf("%d",&num);

        vallogico = verifica(num);

        if (vallogico == 1)
        {
            printf("o numero e positivo\n");
        }
        else
        {
            printf("o valor e negativo\n");
        }
    }
    return (0);
}