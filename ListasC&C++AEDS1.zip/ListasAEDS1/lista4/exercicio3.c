/*Faça um procedimento que recebe 3 valores inteiros por parâmetro e os exiba em ordem
crescente. Faça um programa que leia N conjuntos de 3 valores e acione o procedimento
para cada conjunto. (N deve ser lido do teclado)
*/
#include<stdio.h>

void organizar (int n1,int n2,int n3){
    if (n1 <= n2 && n2 <= n3)
    {
      printf("A ordem crescente: %d %d %d\n", n1, n2, n3);
    }
  else if (n1 <= n3 && n3 <= n2)
    {
      printf("A ordem crescente: %d %d %d\n", n1, n3, n2);
    }
  else if (n2 <= n1 && n1 <= n3)
    {
      printf("A ordem crescente: %d %d %d\n", n2, n1, n3);
    }
  else if (n2 <= n3 && n3 <= n1) 
    {
      printf("A ordem crescente: %d %d %d\n", n2, n3, n1);
    }
  else if (n3 <= n1 && n1 <= n2) 
    {
      printf("A ordem crescente: %d %d %d\n", n3, n1, n2);
    }
  else 
    {
      printf("A ordem crescente: %d %d %d\n", n3, n2, n1);
    }
    
}
int main (void){
    int n1,n2,n3,n,i;
    printf("entre com o numero de vezes que deseja entrar com numeros\n");
    scanf("%d",&n);

    for ( i = 0; i < n; i++)
    {
        printf("entre com os 3 numeros separados por espaco\n");
        scanf("%d %d %d",&n1,&n2,&n3);

        organizar (n1,n2,n3);
    }
    return (0);
}