/*Escreva uma função que recebe por parâmetro um valor inteiro e positivo N e retorna o
valor de S, calculado segundo a fórmula abaixo.
S = 2/4 + 5/5 + 10/6 + 17/7 + 26/8 + ... +(n2+1)/(n+3)
Faça um programa que leia N e imprima o valor retornado pela função.
*/
#include<stdio.h>
float calculo(int n){
int i;
float variavel;
for (i = 0; i < n; i++)
{
    variavel = (n*2 +1)/(n+3);
}

return (variavel);

}
int main (void){
    int n;
    float fim;
    printf("entre com o numero\n");
    scanf("%d",&n);

    fim = calculo(n);
    printf("%2.f",fim);
}